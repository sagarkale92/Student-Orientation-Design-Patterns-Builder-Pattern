package studentOrientation.util;
/**
 * @author Saurabh Chaudhari
 * @author Sagar Kale
 * Interface for CarbonFootPrint
 */

public interface CarbonFootPrintInterface {
	public int getCarbonFootPrintValue();
	public void setValue(int carbonFootprintIn);
}
