package studentOrientation.util;
/**
 * @author Saurabh Chaudhari
 * @author Sagar Kale
 * Interface for Cost
 */

public interface CostInterface {
	public double getCostValue();

	public void setValue(double costIn);
}
