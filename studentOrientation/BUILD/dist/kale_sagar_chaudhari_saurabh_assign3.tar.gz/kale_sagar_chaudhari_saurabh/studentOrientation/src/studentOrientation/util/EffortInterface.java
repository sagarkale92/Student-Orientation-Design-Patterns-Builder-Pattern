package studentOrientation.util;
/**
 * @author Saurabh Chaudhari
 * @author Sagar Kale
 * Interface for Effort.
 */

public interface EffortInterface {
	public int getEffortValue();
	public void setValue(int effortsIn);
}
