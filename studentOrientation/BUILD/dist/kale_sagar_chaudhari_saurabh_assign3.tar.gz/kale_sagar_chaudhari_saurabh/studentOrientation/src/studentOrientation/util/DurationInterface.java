package studentOrientation.util;
/**
 * @author Saurabh Chaudhari
 * @author Sagar Kale
 * Interface for duration.
 */

public interface DurationInterface {
	public int getDuration();
	public void setValue(int durationIn);
}
