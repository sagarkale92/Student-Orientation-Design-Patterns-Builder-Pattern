package studentOrientation.store;
/**
 * @author Saurabh Chaudhari
 * @author Sagar Kale
 * StdoutDisplay Interface with method to write schedules to screen.
 */

public interface StdoutDisplayInterface {
	public void writeSchedulesToScreen();
}